
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'joefitter',
  applicationName: 'crow-api',
  appUid: '5q5ymFS4mTbB72Hy8r',
  orgUid: '32fa0696-88e5-4748-a1c9-4599c4a49071',
  deploymentUid: '2b7db65a-8f2a-4a09-8fb8-2bd4e4990055',
  serviceName: 'crow-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'crow-api-dev-getCrows', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getAssetsForNft, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}