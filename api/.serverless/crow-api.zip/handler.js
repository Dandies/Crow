const anchor = require("@coral-xyz/anchor")
const { program } = require("./anchor")
const mapValues = require("lodash/mapValues")

async function getAllCrows() {
  const crows = await program.account.crow.all()
  return crows
}

function clean(asset) {
  return {
    publicKey: asset.publicKey.toBase58(),
    ...mapValues(asset.account, (value) => {
      if (value instanceof anchor.BN) {
        return value.toString()
      }
      return value
    }),
  }
}

async function getCrow(mint) {
  const crow = (
    await program.account.crow.all([
      {
        memcmp: {
          bytes: mint,
          offset: 8,
        },
      },
    ])
  )[0]

  if (!crow) {
    return null
  }

  const assets = await program.account.asset.all([
    {
      memcmp: {
        bytes: crow.publicKey.toBase58(),
        offset: 8,
      },
    },
  ])

  return {
    publicKey: crow.publicKey,
    assets: assets.map(clean),
  }
}

module.exports.getAssetsForNft = async (event) => {
  const { mint } = event.pathParameters
  if (mint) {
    const crow = await getCrow(event.pathParameters.mint)
    return {
      statusCode: 200,
      body: JSON.stringify({
        crow,
      }),
    }
  } else {
    const crows = await getAllCrows()
    return {
      statusCode: 200,
      body: JSON.stringify({
        crows,
      }),
    }
  }
}
