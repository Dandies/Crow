const anchor = require("@coral-xyz/anchor")

const IDL = require("./include/idl/crow.json")

const connection = new anchor.web3.Connection(process.env.RPC_HOST, { commitment: "processed" })

module.exports.program = new anchor.Program(IDL, new anchor.web3.PublicKey(process.env.PROGRAM_ID), {
  connection,
})
